import random
from datetime import datetime


def lire_fichier(fichier):
    """
    Fonction qui ouvre un fichier et charge son contenu dans une liste.
    Chaque ligne du fichier représente une personnalité.

    :param fichier: Le chemin du fichier à lire.
    :return: Une liste contenant les lignes du fichier.
    """
    try:
        with open(fichier, "r") as f:
            contenu = f.readlines()
        return [ligne.strip() for ligne in contenu]  # Supprimer les sauts de ligne
    except FileNotFoundError:
        print(f"Erreur : Le fichier {fichier} est introuvable.")
        return []


def calculer_age(annee_naissance):
    """
    Calcule l'âge à partir de l'année de naissance.
    :param annee_naissance: L'année de naissance.
    :return: L'âge calculé.
    """
    annee_actuelle = datetime.now().year
    return annee_actuelle - annee_naissance


def generer_pseudonyme(prenom, nom, annee_naissance):
    """
    Génère un pseudonyme au format spécifié.
    :param prenom: Le prénom de la personne.
    :param nom: Le nom de la personne.
    :param annee_naissance: L'année de naissance de la personne.
    :return: Un pseudonyme unique.
    """
    age = calculer_age(annee_naissance)
    lettre_prenom = prenom[0].lower()
    debut_nom = nom[:3].lower()
    nombre_aleatoire = random.randint(10, 99)
    return f"{lettre_prenom}{debut_nom}{age}{nombre_aleatoire}"


def traiter_donnees(donnees):
    """
    Traite les données d'entrée et génère les pseudonymes.
    :param donnees: Liste de chaînes représentant les données d'entrée.
    :return: Liste de pseudonymes générés.
    """
    pseudonymes = []
    for ligne in donnees:
        try:
            prenom, nom, annee_naissance = ligne.split(";")
            annee_naissance = int(annee_naissance)
            pseudonyme = generer_pseudonyme(prenom, nom, annee_naissance)
            pseudonymes.append(pseudonyme)
        except ValueError:
            print(f"Erreur de format dans la ligne : {ligne}")
    return pseudonymes


def ecrire_fichier(fichier, pseudonymes):
    """
    Écrit les pseudonymes générés dans un fichier de sortie.
    :param fichier: Le chemin du fichier de sortie.
    :param pseudonymes: Liste de pseudonymes à écrire.
    """
    try:
        with open(fichier, "w") as f:
            for pseudo in pseudonymes:
                f.write(pseudo + "\n")
        print(f"Résultats écrits dans {fichier}")
    except IOError as e:
        print(f"Erreur d'écriture dans le fichier {fichier} : {e}")


# Exemple d'utilisation
donnees = lire_fichier("testEntree.txt")
pseudonymes = traiter_donnees(donnees)
ecrire_fichier("testSortie.txt", pseudonymes)
