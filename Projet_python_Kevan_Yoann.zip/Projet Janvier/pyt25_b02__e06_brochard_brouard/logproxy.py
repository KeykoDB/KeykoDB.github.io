import os
import csv
from datetime import datetime

# Constantes
LOG_DIRECTORY = "./Fichiers_logs_proxy"  # Répertoire contenant les fichiers de log
CSV_OUTPUT_FILE = "loginfo.csv"  # Nom du fichier CSV de sortie
CSV_HEADERS = [
    "date",
    "heure",
    "adresse_ip_employe",
    "url_consultee",
    "methode_http",
    "code_reponse",
]  # En-têtes du fichier CSV


def main():
    # Étape 1 : Demander une date à l'utilisateur
    user_date = input("Entrez une date au format YYYY-MM-DD : ").strip()

    # Valider le format de la date
    try:
        parsed_date = datetime.strptime(user_date, "%Y-%m-%d")
    except ValueError:
        print("Date invalide. Veuillez respecter le format YYYY-MM-DD.")
        return

    # Étape 2 : Vérifier si le fichier de log correspondant existe
    log_file_name = (
        f"log_proxy_{user_date}.txt"  # Construire le nom du fichier à partir de la date
    )
    log_file_path = os.path.join(
        LOG_DIRECTORY, log_file_name
    )  # Obtenir le chemin complet du fichier

    if not os.path.exists(log_file_path):
        print(f"Fichier de log pour la date {user_date} introuvable.")
        return

    # Étape 3 : Traiter le fichier de log et extraire les données
    extracted_data = []  # Liste pour stocker les données extraites

    try:
        with open(log_file_path, "r") as log_file:
            for line in log_file:
                line = (
                    line.strip()
                )  # Supprimer les espaces inutiles au début et à la fin

                # Supposition sur le format des lignes du fichier : "YYYY-MM-DD HH:MM:SS IP URL METHOD STATUS"
                parts = (
                    line.split()
                )  # Diviser la ligne en parties basées sur les espaces
                if len(parts) < 5:
                    continue  # Ignorer les lignes mal formées

                log_date, log_time, ip, url, method, status = (
                    parts[0],
                    parts[1],
                    parts[2],
                    parts[3],
                    parts[4],
                    parts[5],
                )

                # Filtrer uniquement les lignes correspondant à la date spécifiée
                if log_date == user_date:
                    extracted_data.append(
                        [log_date, log_time, ip, url, method, status]
                    )  # Ajouter les données extraites
    except Exception as e:
        print(f"Erreur lors de la lecture du fichier de log : {e}")
        return

    # Étape 4 : Écrire les données extraites dans un fichier CSV
    try:
        with open(CSV_OUTPUT_FILE, "w", newline="") as csv_file:
            writer = csv.writer(
                csv_file, delimiter=";"
            )  # Initialiser l'écriture CSV avec un séparateur ';'

            # Écrire les en-têtes dans le fichier CSV
            writer.writerow(CSV_HEADERS)

            # Écrire les lignes de données extraites
            writer.writerows(extracted_data)

        print(f"Données extraites et enregistrées dans {CSV_OUTPUT_FILE}.")
    except Exception as e:
        print(f"Erreur lors de l'écriture du fichier CSV : {e}")


if __name__ == "__main__":
    main()
