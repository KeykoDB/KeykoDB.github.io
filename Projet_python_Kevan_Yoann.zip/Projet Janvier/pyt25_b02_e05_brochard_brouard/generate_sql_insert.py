import os

# Constantes
LOG_DIRECTORY = "./Fichiers_logs_proxy"  # Répertoire contenant les fichiers de logs
SQL_OUTPUT_DIRECTORY = "./SQL_Files"  # Répertoire pour les fichiers SQL générés
TABLE_NAME = "acces_logs"  # Nom de la table dans la base de données


# Fonction pour lister les fichiers logs dans le répertoire
def lister_fichiers_log():
    # Cette fonction liste les fichiers logs disponibles dans le répertoire LOG_DIRECTORY
    fichiers = os.listdir(LOG_DIRECTORY)
    fichiers_logs = []  # Liste pour stocker les fichiers logs
    for fichier in fichiers:
        # On vérifie si le fichier commence par "log_proxy_" et finit par ".txt"
        if fichier.startswith("log_proxy_") and fichier.endswith(".txt"):
            fichiers_logs.append(fichier)
    return fichiers_logs


# Fonction pour afficher un menu interactif et sélectionner un fichier log
def selectionner_fichier_log(fichiers_logs):
    # Cette fonction affiche un menu pour que l'utilisateur sélectionne un fichier log
    print("Fichiers logs disponibles :")
    for i in range(len(fichiers_logs)):
        print(f"{i + 1}. {fichiers_logs[i]}")

    while True:
        choix = input("Entrez le numéro du fichier à traiter : ")
        if choix.isdigit():
            choix = int(choix)
            if choix >= 1 and choix <= len(fichiers_logs):
                return fichiers_logs[choix - 1]
        print("Choix invalide. Essayez encore.")


# Fonction pour lire le contenu du fichier log sélectionné
def lire_fichier_log(chemin_fichier, date_log):
    # Cette fonction lit le fichier log et extrait les données ligne par ligne
    donnees_log = []  # Liste pour stocker les données extraites
    with open(chemin_fichier, "r") as fichier:
        for ligne in fichier:
            ligne = ligne.strip()  # Supprime les espaces inutiles
            parties = ligne.split()  # Découpe la ligne en morceaux
            if len(parties) >= 5:  # On vérifie qu'il y a au moins 5 éléments
                heure = parties[0]
                ip = parties[1]
                methode = parties[2]
                statut = parties[3]
                url = " ".join(
                    parties[4:]
                )  # Reconstruit l'URL avec les parties restantes
                donnees_log.append((date_log, heure, ip, url, methode, statut))
            else:
                print(
                    "Ligne ignorée (format invalide) :", ligne
                )  # Affiche les lignes incorrectes
    return donnees_log


# Fonction pour générer le fichier SQL à partir des données du log
def generer_fichier_sql(nom_fichier_log, donnees_log):
    # Cette fonction crée un fichier SQL pour insérer les données dans la base
    date_log = nom_fichier_log.replace("log_proxy_", "").replace(".txt", "")
    nom_fichier_sql = "insert_log_" + date_log + ".sql"
    chemin_fichier_sql = os.path.join(SQL_OUTPUT_DIRECTORY, nom_fichier_sql)

    # Vérifie si le dossier de sortie existe, sinon le crée
    if not os.path.exists(SQL_OUTPUT_DIRECTORY):
        os.makedirs(SQL_OUTPUT_DIRECTORY)

    # Ouvre le fichier SQL en écriture
    with open(chemin_fichier_sql, "w") as fichier_sql:
        fichier_sql.write("-- Insertion des logs pour la date " + date_log + "\n")
        fichier_sql.write("-- Table : " + TABLE_NAME + "\n\n")

        for entree in donnees_log:
            date = entree[0]
            heure = entree[1]
            ip = entree[2]
            url = entree[3]
            methode = entree[4]
            statut = entree[5]
            commande_sql = (
                "INSERT INTO "
                + TABLE_NAME
                + " (date, heure, adresse_ip_employe, url_consultee, methode_http, code_reponse) VALUES ('"
                + date
                + "', '"
                + heure
                + "', '"
                + ip
                + "', '"
                + url
                + "', '"
                + methode
                + "', '"
                + statut
                + "');\n"
            )
            fichier_sql.write(commande_sql)  # Écrit la commande SQL dans le fichier

    print("Fichier SQL généré :", chemin_fichier_sql)


# Fonction principale du programme
def main():
    # Cette fonction coordonne toutes les étapes du programme
    fichiers_logs = lister_fichiers_log()  # Liste des fichiers logs
    if len(fichiers_logs) == 0:
        print("Aucun fichier log trouvé dans le répertoire.")
        return

    fichier_selectionne = selectionner_fichier_log(
        fichiers_logs
    )  # Sélection d'un fichier
    chemin_fichier = os.path.join(LOG_DIRECTORY, fichier_selectionne)

    date_log = fichier_selectionne.replace("log_proxy_", "").replace(
        ".txt", ""
    )  # Extrait la date du fichier

    donnees_log = lire_fichier_log(
        chemin_fichier, date_log
    )  # Lit et analyse le fichier

    if len(donnees_log) == 0:
        print("Aucune donnée valide trouvée dans le fichier log. Vérifiez son format.")
        return

    generer_fichier_sql(fichier_selectionne, donnees_log)  # Génère le fichier SQL


if __name__ == "__main__":
    main()
